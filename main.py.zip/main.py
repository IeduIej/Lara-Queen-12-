
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")

products = [
    {
        "name": "روج ماك كلاسيك",
        "price": "15,000 دينار",
        "image": "https://i.imgur.com/1X4F2qf.jpg"
    },
    {
        "name": "فاونديشن ميبلين فيت مي",
        "price": "20,000 دينار",
        "image": "https://i.imgur.com/GSPaQVe.jpg"
    }
]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = []
    for idx, product in enumerate(products):
        keyboard.append([InlineKeyboardButton(product["name"], callback_data=str(idx))])
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("أهلاً بيچ! اختاري المنتج اللي يعجبچ من القائمة:", reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    product = products[int(query.data)]
    text = f"📦 {product['name']}
💰 السعر: {product['price']}"
    await query.message.reply_photo(photo=product["image"], caption=text)

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    print("البوت يشتغل ✅")
    app.run_polling()
